#ifndef _MYBOOL_H
#define _MYBOOL_H

#define true 1
#define false 0

typedef int mybool;

#endif
